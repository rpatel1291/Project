package project;
import java.io.IOException;
public class Main {
	/**
	 * The beginning portion of the program that calls the GUI function 
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException{
		@SuppressWarnings("unused")
		GUI home = new GUI();
	}
}
