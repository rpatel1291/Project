F.O.R.K. - Food Ordered Right Karefully

This program is to help the potential customer that is ordering online to simplify their life.


The top most successful and growing business is the restaurant business. Why is this? Restaurants businesses cater to the customers request. This means that the product produced by the business can change to fit what the customer needs. In addition to that people love food and it has been like this for generations. For a business to stay successful for so long it needs to stay up to date with technology. As soon as everyone had a home phone people were able to make over the phone orders. With the help of personal computers and the Internet, restaurants were able to post digital copy of their menu. The most recent trend is to order food by any Internet connected device. However, what makes this different from other service that allows food to be ordered online is that this service picks out food items based on the restaurant and ingredients for those customers with allergies. Now people can order food without worrying about "What's in it?" and "Can I eat it?". Order with confidence.




Bugs in the program:
    1. Cannot access/input data into the database.
    2. Displaying the query results 
    3. 
